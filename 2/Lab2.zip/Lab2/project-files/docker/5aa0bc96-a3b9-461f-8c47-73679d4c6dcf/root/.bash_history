vtysh -c "show ip route ospf"
vtysh -c "show ip ospf route" | grep -i "172.16.9"
vtysh -c "show ip ospf route" | grep -i "172.16.9"
vtysh -c "show ip route ospf" | grep 172.16.9
vtysh -c "show ip route ospf" | grep 172.16.9
vtysh -c "show ip route ospf" | grep 172.16.9
vtysh -c "show ip ospf route" | grep -i "172.16.9"
SRC=<origem>
for d in 172.16.9.1 172.16.9.33 172.16.9.65 172.16.9.97 172.16.0.1 172.16.12.1 172.16.11.1 172.16.10.1 192.168.23.1 192.168.23.4 192.168.23.5 192.168.34.1 192.168.34.2 192.168.45.2 192.168.45.3 192.168.13.5 192.168.13.6 192.168.12.6 192.168.12.7; do ping -c1 -W1 -I $SRC $d >/dev/null && echo "OK   $d" || echo "FALHA $d"; done
vtysh -c "show ip route ospf" | grep 172.16.9
vtysh -c "show ip ospf route" | grep -i "172.16.9"
SRC=172.16.0.1
for d in 172.16.9.1 172.16.9.33 172.16.9.65 172.16.9.97 172.16.0.1 172.16.12.1 172.16.11.1 172.16.10.1 192.168.23.1 192.168.23.4 192.168.23.5 192.168.34.1 192.168.34.2 192.168.45.2 192.168.45.3 192.168.13.5 192.168.13.6 192.168.12.6 192.168.12.7; do ping -c1 -W1 -I $SRC $d >/dev/null && echo "OK   $d" || echo "FALHA $d"; done
