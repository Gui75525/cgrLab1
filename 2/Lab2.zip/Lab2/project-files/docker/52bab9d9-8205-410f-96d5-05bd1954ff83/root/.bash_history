vtysh -c "show ip route ospf"
vtysh -c "show ip route ospf"
vtysh -c "show ip route ospf"
vtysh -c "show ip route ospf"
vtysh -c "show ip route ospf"
vtysh -c "show ip route ospf"
vtysh -c "show ip route ospf"
vtysh -c "show ip route ospf"
vtysh -c "show ip route ospf"
vtysh -c "show ip route ospf"
vtysh -c "show ip route ospf"
vtysh -c "show ip ospf neighbor"
vtysh -c "show ip route ospf"
vtysh -c "show ip ospf neighbor"
vtysh -c "show ip route ospf"
vtysh -c "show ip ospf neighbor"
vtysh -c "show ip route ospf"
ip -br addr show lo
grep -n -A3 "iface lo" /etc/network/interfaces
sed -i '/^iface lo inet loopback/a\    address 172.16.9.1/27\n    address 172.16.9.33/27\n    address 172.16.9.65/27\n    address 172.16.9.97/27' /etc/network/interfaces
ifreload -a
ip -br addr show lo
ip -br addr show lo
vtysh -c "show ip ospf" | grep -i -E "ABR|area 20|Area ID|range"
vtysh -c "show ip ospf database summary self-originate"
vtysh -c "show running-config" | grep -E "area|abr"
vtysh -c "show ip ospf" | grep -i -E "ABR|area 20|Area ID|range"
vtysh -c "show ip ospf database summary self-originate"
vtysh -c "show running-config" | grep -E "area|abr"
vtysh -c "configure terminal"       -c "router ospf"       -c "no area 20 range 172.16.9.0/25"       -c "area 20 range 172.16.9.0/25"       -c "end"       -c "write memory"
vtysh -c "show ip ospf interface lo" | grep -i area
vtysh -c "show running-config" | grep -B1 -A2 "interface lo"
vtysh -c "configure terminal"       -c "interface lo"       -c "no ip ospf area"       -c "ip ospf area 20"       -c "end"       -c "write memory"
vtysh -c "show ip ospf interface lo" | grep -i area
vtysh -c "show ip ospf database summary self-originate" | grep "Link State ID: 172.16.9"
SRC=<origem>
for d in 172.16.9.1 172.16.9.33 172.16.9.65 172.16.9.97 172.16.0.1 172.16.12.1 172.16.11.1 172.16.10.1 192.168.23.1 192.168.23.4 192.168.23.5 192.168.34.1 192.168.34.2 192.168.45.2 192.168.45.3 192.168.13.5 192.168.13.6 192.168.12.6 192.168.12.7; do ping -c1 -W1 -I $SRC $d >/dev/null && echo "OK   $d" || echo "FALHA $d"; done
vtysh -c "show ip ospf database summary self-originate" | grep "Link State ID: 172.16.9"
SRC=172.16.10.1
for d in 172.16.9.1 172.16.9.33 172.16.9.65 172.16.9.97 172.16.0.1 172.16.12.1 172.16.11.1 172.16.10.1 192.168.23.1 192.168.23.4 192.168.23.5 192.168.34.1 192.168.34.2 192.168.45.2 192.168.45.3 192.168.13.5 192.168.13.6 192.168.12.6 192.168.12.7; do ping -c1 -W1 -I $SRC $d >/dev/null && echo "OK   $d" || echo "FALHA $d"; done
SRC=172.16.9.1
for d in 172.16.9.1 172.16.9.33 172.16.9.65 172.16.9.97 172.16.0.1 172.16.12.1 172.16.11.1 172.16.10.1 192.168.23.1 192.168.23.4 192.168.23.5 192.168.34.1 192.168.34.2 192.168.45.2 192.168.45.3 192.168.13.5 192.168.13.6 192.168.12.6 192.168.12.7; do ping -c1 -W1 -I $SRC $d >/dev/null && echo "OK   $d" || echo "FALHA $d"; done
vtysh -c "show ip ospf neighbor"
vtysh -c "show ip route ospf" | grep -E "192.168.13|192.168.12|172.16.10"
vtysh -c "show ip ospf neighbor"
vtysh -c "show ip ospf neighbor"
vtysh -c "show ip ospf database"
vtysh -c "show ip route"
